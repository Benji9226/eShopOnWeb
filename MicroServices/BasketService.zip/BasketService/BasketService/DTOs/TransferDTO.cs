﻿namespace BasketService.DTOs;

public class TransferDTO
{
    public string AnonymousId { get; set; }
    public string UserName { get; set; }
}
